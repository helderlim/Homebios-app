import styled from 'styled-components';

export const Container = styled.View`
   
    flex-direction:row;
    margin-bottom:8px;
`;

export const ContainerImage = styled.View`
    
`;

export const ContainerImageRight = styled.View`
    margin-left:7px;
`;

export const ImageHome = styled.Image`
 height:116px;
 width:167px;
 margin-top:10px;
 border-radius:3px;
 
`;

