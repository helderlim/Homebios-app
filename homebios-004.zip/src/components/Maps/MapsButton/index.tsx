import React from 'react';

import { Container, Texto } from './styles';

const MapsButton: React.FC = () => {
  return (
    <Container>
     <Texto>Mapa</Texto>
    </Container>
  );
};

export default MapsButton;
