import styled from 'styled-components';

export const Container = styled.View`
    margin-bottom:8px;
`;
