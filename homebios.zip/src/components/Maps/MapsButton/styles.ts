import styled from 'styled-components';

export const Container = styled.View`

`;

export const Texto = styled.Text`
 color: red; 
`;
