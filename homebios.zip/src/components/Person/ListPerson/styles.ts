import styled from 'styled-components';

export const Container = styled.View`

`;

export const Text = styled.Text`
 font-size:24px;
`;

export const Line = styled.Text`
 border:0.5px;
 height:0px;
 width:335px;
`;
export const Box = styled.TouchableOpacity`
    flex-direction:row;
    align-items:center;
    margin-top:18px;
    
`;

export const View = styled.Image`
    margin-left:120px;
    height:20px;
    width:20px;
`;

export const Image = styled.Image`
margin-left:52px;
    height:20px;
    width:20px;
`;