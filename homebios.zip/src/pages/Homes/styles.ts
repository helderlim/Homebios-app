import styled from 'styled-components';

export const Container = styled.View`
margin-top:28px;
margin-left:10px;
`;

export const Texto = styled.Text`
    align-self:center;
    text-align:center;
    margin-top: 30px;
    margin-bottom:4px;
`;

export const L = styled.View`
    border: 1px  black;
    margin-right:14px;
`;
