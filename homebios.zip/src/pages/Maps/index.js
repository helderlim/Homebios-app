import React from 'react';
import { Container } from './styles';
import Map from '../../components/Maps/Map/index'

function Maps () {
  

  return (
    <Container>
      <Map/>
    </Container>
  );
};

export default Maps;
