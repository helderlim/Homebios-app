import styled from 'styled-components';

export const Container = styled.View`
 flex:1;
 margin-left:10px;
`;

export const Title = styled.Text`
 margin-top:65px;
 font-size:35px;
`;



